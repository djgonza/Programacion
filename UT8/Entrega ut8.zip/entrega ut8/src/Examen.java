import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

/**
 * Esta clase guarda en un map las notas que han sacado los alumnos de un curso
 * en un determinado control de tipo test
 * 
 * La clave es el nombre del alumno (siempre se guarda en mayúsculas) y el valor
 * asociado la nota
 */
public class Examen {
	private static final String FIC_ENTRADA = "datos/respuestas-alumnos.txt"; // el
																				// nombre
																				// del
																				// fichero
																				// con
																				// las
																				// respuestas
																				// dadas
																				// por
																				// los
																				// alumnos
	private static final String FIC_SALIDA = "datos/orden-nota.txt"; // fichero
																		// de
																		// saldia
																		// para
																		// guardar
																		// resultados
	private Map<String, Double> notas;
	private CorrectorExamen corrector;

	/**
	 * Constructor de la clase Examen
	 * 
	 */
	public Examen(CorrectorExamen corrector) {
		notas = new TreeMap<>();
		this.corrector = corrector;
	}

	/**
	 * Añade al map el alumno (siempre en mayúsculas) junto con su nota
	 * 
	 */
	public void add(String alumno, double nota) {
		notas.put(alumno.toUpperCase(), nota);
	}

	/**
	 * Lee del fichero FIC_ENTRADA las respuestas que ha dado cada alumno al
	 * control y guarda en el map la nota de cada alumno en el test
	 * 
	 * Para el cálculo de la nota obtenida por el alumno nos ayudaremos del
	 * objeto CorrectorExamen
	 * 
	 * Cada línea del fichero contiene los datos de un alumno de la forma
	 * nombrealumno:respuesta:respuesta:respuesta:......
	 * 
	 * Asumimos los datos correctos Por ejemplo pedro:a:b:c: :d:a:a: :b:b
	 * 
	 * Con BufferedReader y capturando las excepciones
	 */
	public void leerDeFichero() {

		File f = null;
		BufferedReader br = null;

		try {

			f = new File(FIC_ENTRADA);
			br = new BufferedReader(new FileReader(f));

			String linea = br.readLine();

			while (linea != null) {

				String[] datos = linea.split(":");

				char[] datosParseados = new char[datos.length - 1];

				for (int i = 0; i < datosParseados.length; i++) {
					datosParseados[i] = datos[i + 1].charAt(0);
				}

				notas.put(datos[0], corrector.evaluarTest(datosParseados));

				linea = br.readLine();
			}

		} catch (FileNotFoundException e) {
			System.out.println("Error al leer el fichero");
		} catch (IOException e) {
			System.out.println("Error al leer la informacion del fichero");
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("Error al leer el fichero");
				}
			}
		}

	}

	/**
	 * Devuelve la nota del alumno indicado Si no existe el alumno se lanza la
	 * excepción personalizada AlumnoNoExistenteException con el mensaje
	 * adecuado
	 */
	public double notaDe(String alumno) {
		return notas.get(alumno.toUpperCase());
	}

	/**
	 * Calcula y devuelve cuántos han aprobado el test
	 */
	public int aprobados() {
		int aprobados = 0;
		for (Entry<String, Double> nota : notas.entrySet()) {
			if (nota.getValue() >= 5)
				aprobados++;
		}
		return aprobados;
	}

	/**
	 * Representación textual del map Con el conjunto de entradas
	 * 
	 * Cada alumno con su nota, nombre formateado a 15 posiciones alineado a la
	 * derecha, nota formateada a 6 posiciones (2 de ellas decimales)
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Entry<String, Double> nota : notas.entrySet()) {

			sb.append(String.format("%15s", nota.getKey()));
			sb.append(String.format("%6.2f", nota.getValue()));
			sb.append('\n');
		}
		return sb.toString();
	}

	/**
	 * Devolver una colección ArrayList con los nombres de los alumnos ordenados
	 * de mayor a menor nota
	 * 
	 * Habrá que ordenar con un comparador la colección de entradas (ver
	 * enunciado) puesto que no podemos ordenar un map por sus valores
	 * 
	 */
	public List<String> ordenadosPorNota() {
		List<Map.Entry<String, Double>> lista = new ArrayList<Map.Entry<String, Double>>(notas.entrySet());
		Collections.sort(lista, new Comparator<Map.Entry<String, Double>>() {
			public int compare(Map.Entry<String, Double> uno, Map.Entry<String, Double> dos) {
				double a = uno.getValue();
				double b = dos.getValue();
				if (a > b)
					return -1;
				if (a < b)
					return 1;
				return 0;
			}
		});
		List<String> nombres = new ArrayList<>();
		for (Map.Entry<String, Double> entradas : lista) {
			nombres.add(entradas.getKey());
		}
		return nombres;
	}

	/**
	 * Guarda en el fichero de texto FIC_SALIDA el nombre de cada alumno y su
	 * nota en orden decreciente de nota
	 * 
	 * En cada línea aparece el nombre del alumno y la nota, ambos formateados
	 * (nombre ocupará 15 posiciones y estará ajustado a la derecha, nota
	 * formateado a 2 decimales ocupando 6 espacios y ajustado a la derecha)
	 * 
	 * Se propagan las excepciones
	 * 
	 * @throws IOException
	 */
	public void guardarOrdenadosPorNota() throws IOException, FileNotFoundException {
		File f = new File(FIC_SALIDA);
		BufferedWriter bw = new BufferedWriter(new FileWriter(f));
		List<String> ord = ordenadosPorNota();
		for (String nombre : ord) {
			bw.write(String.format("%15s %-6.2f", nombre, notas.get(nombre)));
		}
		bw.close();
	}

	/**
	 *  
	 */
	public void print() {
		System.out.println(this.toString());
	}

	/**
	 * Crea el corrector, crea el objeto Examen, lee del fichero las respuestas
	 * de los alumnos y guarda los resultados en el fichero de salida
	 * 
	 * Propaga las excepciones que se produzcan
	 * 
	 * @throws IOException
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		CorrectorExamen ce = new CorrectorExamen();
		Examen demo = new Examen(ce);
		demo.leerDeFichero();
		System.out.println(demo.aprobados());
		demo.print();
		demo.guardarOrdenadosPorNota();
	}

}
