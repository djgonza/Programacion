import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Un objeto de esta clase guarda en un array de caracteres las respuestas
 * correctas (la solución) de un examen tipo test así como el valor de la
 * respuesta correcta (que se sumará) y el valor de la incorrecta (que se
 * restará), Las respuestas en blanco no puntúan
 * 
 * 
 * 
 */
public class CorrectorExamen {
	private static final String SOLUCION = "datos/solucion.txt"; // el fichero
																	// que
																	// contiene
																	// la
																	// solución
	private static final char ESPACIO = ' ';
	private char[] solucion; // todas las respuestas correctas del test
	private double valorCorrecta; // valor de la correcta
	private double valorIncorrecta; // cantidad a restar por incorrecta

	/**
	 * Constructor de la clase CorrectorExamen Todas las posibles excepciones se
	 * propagan
	 * 
	 * @throws FileNotFoundException
	 */
	public CorrectorExamen() throws FileNotFoundException {
		leerSolucion(SOLUCION);
	}

	/**
	 * accesor para el peso de la respuesta correcta
	 */
	public double getValorCorrecta() {
		return valorCorrecta;
	}

	/**
	 * accesor para el peso de la respuesta incorrecta
	 */
	public double getValorIncorrecta() {
		return valorIncorrecta;
	}

	/**
	 * accesor para las respuestas del test
	 */
	public char[] getSolucion() {
		return solucion;
	}

	/**
	 * Lee del fichero de texto cuyo nombre se pasa como parámetro dos líneas: -
	 * en la primera se indica el valor de cada respuesta correcta y lo que se
	 * descontará por cada incorrecta - en la segunda línea están las respuestas
	 * del examen
	 * 
	 * Ejemplo 1: -0.25 1ª línea con separador : acbaaccbdd 2ª línea sin
	 * separador
	 * 
	 * 
	 * Asumimos la estructura del fichero sin errores
	 * 
	 * Las respuestas leídas se guardan en el array solucion
	 * 
	 * Usa la clase Scanner para leer el fichero
	 * 
	 * Todas las posibles excepciones se propagan
	 * 
	 * @throws FileNotFoundException
	 */
	private void leerSolucion(String nombre) throws FileNotFoundException {

		File f = new File(nombre);
		Scanner sc = new Scanner(f);

		String calificacion = sc.nextLine();

		valorCorrecta = Double.valueOf(calificacion.split(":")[0]);
		valorIncorrecta = Double.valueOf(calificacion.split(":")[1]);

		String respuestas = sc.nextLine();
		solucion = new char[respuestas.length()];
		for (int i = 0; i < respuestas.length(); i++) {
			solucion[i] = respuestas.charAt(i);
		}

	}

	/**
	 * Dado un array con las respuestas que ha dado un alumno al examen el
	 * método comprueba los aciertos y errores y devuelve el valor obtenido en
	 * el test
	 * 
	 * Las respuestas en blanco no se contabilizan
	 * 
	 */
	public double evaluarTest(char[] test) {

		double resultado = 0;

		for (int i = 0; i < test.length; i++) {
			if (test[i] != ESPACIO) {
				if (test[i] == solucion[i]) {
					resultado += valorCorrecta;
				} else {
					resultado -= valorIncorrecta;
				}
			}
		}

		return resultado;

	}

}
