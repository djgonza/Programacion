
public class Curso
{
	private String nombre;
	private TreeMap<String, Integer> mapCurso;
	
	/**
	 * constructor
	 * 
	 * @param nombre
	 *            el nombre del curso
	 */
	public Curso(String nombre)
	{
		this.nombre = nombre;
		this.mapCurso = new TreeMap<>();
	}
	
	/**
	 * añadir nombre del alumno asociado a su nota
	 * 
	 * @param nombre
	 * @param nota
	 */
	public void addAlumno(String nombre, int nota)
	{
	
	}
	
	/**
	 * calcula y devuelve la media del curso
	 * 
	 * @con el conjunto de entradas
	 */
	public double mediaCurso()
	{
	
	}
	
	/**
	 * calcula y devuelve el total de aprobados
	 * 
	 * @return
	 */
	public int totalAprobados()
	{
	
	}
	
	/**
	 * calcula y devuelve un map donde las claves son ahora las diferentes notas
	 * y cada clave se asocia con la lsita de alumnos que han obtneido esa nota
	 */
	public TreeMap<Integer, ArrayList<String>> obtenerEstadisticas()
	{
	
	}
	
	/**
	 * representación textual del curso. Usar conjunto de claves
	 */
	public String toString()
	{
	
	}
	
	 
//	public static void main(String[] args)
//	{
//		if (args.length != 1)
//		{
//			System.out.println("Error, Sintaxis: java Curso <nombre-curso>");
//			return;
//		}
//		Curso curso = new Curso(args[0]);
//		curso.addAlumno("Eduardo", 4);
//		curso.addAlumno("Javier", 8);
//		curso.addAlumno("Leyre", 9);
//		curso.addAlumno("Alazne", 8);
//		curso.addAlumno("Gorka", 3);
//		curso.addAlumno("Alvaro", 9);
//		
//		System.out.println(curso.toString());
//		System.out.println("Total aprobados: " + curso.totalAprobados());
//		System.out.println(
//				"Media curso: " + String.format("%5.2f", curso.mediaCurso()));
//				
//		TreeMap<Integer, ArrayList<String>> resul = curso.obtenerEstadisticas();
//		System.out.println(resul);
//	}
	
}
