
/**
 *  Clase que inicia la aplicaci�n
 */
public class AppMaquinaEscribir
{
 
    public static void main(String[] args)
    {
        MaquinaEscribir maquina = new MaquinaEscribir();
        GuiMaquinaEscribir demo = new GuiMaquinaEscribir(maquina);
         
    }
}
