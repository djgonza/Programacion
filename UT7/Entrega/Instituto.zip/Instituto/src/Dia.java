
/**
 * 
 * 
 * Solo se enumeran los días en que se dan conferencias
 */
public enum Dia
{
    LUNES, MARTES, MIERCOLES, JUEVES, VIERNES;
}